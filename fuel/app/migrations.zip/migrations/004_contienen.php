<?php 
namespace Fuel\Migrations;

class Contienen
{
	function up()
	{
		\DBUtil::create_table('contienen', array(
            'id_video' => array('type' => 'int', 'constraint' => 11),
            'id_lista' => array('type' => 'int', 'constraint' => 11)
            
        	), 
			array('id_video', 'id_lista'), true, 'InnoDB', 'utf8_general_ci',
		    array(
		        array(
		            'constraint' => 'deContienenAVideos',
		            'key' => 'id_video',
		            'reference' => array(
		                'table' => 'videos',
		                'column' => 'id',
		            ),
		            'on_update' => 'CASCADE',
		            'on_delete' => 'RESTRICT'
		        ), 
		        array(
		            'constraint' => 'deContienenAListas',
		            'key' => 'id_lista',
		            'reference' => array(
		                'table' => 'listas',
		                'column' => 'id',
		            ),
		            'on_update' => 'CASCADE',
		            'on_delete' => 'RESTRICT'
		        )
		    )
		);
	}

	function down()
    {
       \DBUtil::drop_table('contienen');
    }
}
